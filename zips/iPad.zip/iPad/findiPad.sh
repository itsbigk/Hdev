#!/bin/sh

plutil -convert xml1 ~/Library/Preferences/com.apple.iPod.plist

IPAD=$(cat ~/Library/Preferences/com.apple.iPod.plist | grep -A1 -E '<key>Connected</key>|<key>Device Class</key>|<key>Serial Number</key>' | grep -v '^--$' | grep -vE '<key>Device Class</key>|<key>Serial Number</key' | sed 's/^\s*//; s/<.\{3,7\}>//g' | while read C; do read WHEN ; read WHAT; read SERIAL; echo "$WHEN::$WHAT::$SERIAL"; done | grep '::iPad::' | sort | tail -n1)
SERIAL=$(echo "$IPAD" | awk -F '::' '{ print $3; }')
WHEN=$(echo "$IPAD" | awk -F '::' '{ print $1; }')

echo $SERIAL > ~/Desktop/serial.txt
